"""Leak-resistant, offline crypto backtester for fixed local candle CSV files.

The module performs no network access. A strategy never receives the full market
array during evaluation; it receives a copied, read-only causal window ending at
the decision bar. A decision made after bar t closes is executed at bar t+1 open
and earns the t+1-open to t+2-open return.

Edit or import `strategy_factory` for a new bot. Do not edit the split logic.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from dataclasses import asdict, dataclass
from math import isfinite, sqrt
from pathlib import Path
from typing import Callable, Mapping, Protocol, Sequence

import numpy as np


FIELDS = ("open_time_ms", "close_time_ms", "open", "high", "low", "close", "volume")
PRICE_FIELDS = ("open", "high", "low", "close")


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class CandleData:
    open_time_ms: np.ndarray
    close_time_ms: np.ndarray
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    volume: np.ndarray
    source_path: str
    source_sha256: str

    def __len__(self) -> int:
        return len(self.close)

    def slice(self, start: int, end: int) -> "CandleData":
        if not 0 <= start < end <= len(self):
            raise ValueError("invalid candle slice")
        values = {
            field: np.asarray(getattr(self, field)[start:end]).copy()
            for field in FIELDS
        }
        for value in values.values():
            value.flags.writeable = False
        return CandleData(**values, source_path=self.source_path, source_sha256=self.source_sha256)


def _validate_candles(values: Mapping[str, np.ndarray]) -> None:
    lengths = {len(values[field]) for field in FIELDS}
    if len(lengths) != 1 or not lengths or next(iter(lengths)) < 4:
        raise ValueError("aligned candle columns with at least four rows required")
    for field in FIELDS:
        array = np.asarray(values[field])
        if array.ndim != 1 or np.any(~np.isfinite(array.astype(float))):
            raise ValueError(f"{field} must be a finite one-dimensional column")
    if np.any(np.diff(values["open_time_ms"]) <= 0):
        raise ValueError("open timestamps must be strictly increasing")
    if np.any(values["close_time_ms"] < values["open_time_ms"]):
        raise ValueError("close timestamp precedes open timestamp")
    if any(np.any(values[field] <= 0) for field in PRICE_FIELDS):
        raise ValueError("OHLC prices must be positive")
    if np.any(values["volume"] < 0):
        raise ValueError("volume must be nonnegative")
    body_low = np.minimum(values["open"], values["close"])
    body_high = np.maximum(values["open"], values["close"])
    if np.any(values["low"] > body_low) or np.any(values["high"] < body_high):
        raise ValueError("OHLC geometry is inconsistent")
    if np.any(values["low"] > values["high"]):
        raise ValueError("low exceeds high")


def load_candles_csv(path: str | Path) -> CandleData:
    """Load one local CSV. This function contains no downloader or URL support."""
    source = Path(path).resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    columns: dict[str, list[float]] = {field: [] for field in FIELDS}
    with source.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = set(FIELDS) - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"missing CSV columns: {sorted(missing)}")
        for row_number, row in enumerate(reader, start=2):
            try:
                columns["open_time_ms"].append(int(row["open_time_ms"]))
                columns["close_time_ms"].append(int(row["close_time_ms"]))
                for field in PRICE_FIELDS + ("volume",):
                    columns[field].append(float(row[field]))
            except (TypeError, ValueError) as error:
                raise ValueError(f"invalid numeric value on CSV row {row_number}") from error
    arrays = {
        field: np.asarray(items, dtype=np.int64 if field.endswith("_ms") else float)
        for field, items in columns.items()
    }
    _validate_candles(arrays)
    for array in arrays.values():
        array.flags.writeable = False
    return CandleData(
        **arrays, source_path=str(source), source_sha256=sha256_file(source),
    )


@dataclass(frozen=True)
class CausalWindow:
    """Copied, read-only history ending at the decision bar."""
    start_index: int
    end_index: int
    open_time_ms: np.ndarray
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    volume: np.ndarray

    def __len__(self) -> int:
        return len(self.close)


def causal_window(data: CandleData, end_index: int, lookback: int) -> CausalWindow:
    if not isinstance(lookback, int) or lookback < 2:
        raise ValueError("lookback must be an integer of at least two")
    if not 0 <= end_index < len(data):
        raise ValueError("end_index outside data")
    start = max(0, end_index - lookback + 1)
    arrays = {}
    for field in ("open_time_ms", "open", "high", "low", "close", "volume"):
        value = np.asarray(getattr(data, field)[start:end_index + 1]).copy()
        value.flags.writeable = False
        arrays[field] = value
    return CausalWindow(start, end_index, **arrays)


class Strategy(Protocol):
    def fit(self, training_data: CandleData) -> None: ...
    def decide(self, history: CausalWindow) -> float: ...


StrategyFactory = Callable[[Mapping[str, float | int]], Strategy]


@dataclass(frozen=True)
class Fold:
    train_start: int
    train_end: int
    test_start: int
    test_end: int


@dataclass(frozen=True)
class BacktestMetrics:
    total_return: float
    maximum_drawdown: float
    annualized_sharpe: float
    trade_sides: int
    turnover: float
    cost_paid_fraction: float
    invested_fraction: float
    evaluated_returns: int


@dataclass(frozen=True)
class FoldResult:
    fold: Fold
    metrics: BacktestMetrics
    decisions: tuple[float, ...]
    net_returns: tuple[float, ...]


def _maximum_drawdown(equity: np.ndarray) -> float:
    if len(equity) == 0:
        return 0.0
    peaks = np.maximum.accumulate(equity)
    return float(np.max(1.0 - equity / peaks))


def infer_bars_per_year(data: CandleData) -> float:
    intervals = np.diff(data.open_time_ms.astype(float))
    median_ms = float(np.median(intervals))
    if not isfinite(median_ms) or median_ms <= 0:
        raise ValueError("cannot infer candle interval")
    return 365.0 * 24.0 * 60.0 * 60.0 * 1000.0 / median_ms


def evaluate_fold(
    data: CandleData, fold: Fold, strategy_factory: StrategyFactory,
    parameters: Mapping[str, float | int], *, lookback: int = 256,
    fee_per_side: float = 0.0010, slippage_per_side: float = 0.0002,
    minimum_position: float = -1.0, maximum_position: float = 1.0,
) -> FoldResult:
    """Fit on train only; execute test decisions one open after observation."""
    if not (0 <= fold.train_start < fold.train_end <= fold.test_start < fold.test_end <= len(data) - 2):
        raise ValueError("invalid or noncausal fold")
    if any(not isfinite(x) or x < 0 for x in (fee_per_side, slippage_per_side)):
        raise ValueError("costs must be finite and nonnegative")
    if not isfinite(minimum_position) or not isfinite(maximum_position) or minimum_position > maximum_position:
        raise ValueError("invalid position bounds")

    strategy = strategy_factory(dict(parameters))
    strategy.fit(data.slice(fold.train_start, fold.train_end))
    cost_rate = fee_per_side + slippage_per_side
    decisions: list[float] = []
    net_returns: list[float] = []
    current = 0.0
    turnover_total = 0.0
    cost_total = 0.0

    for decision_index in range(fold.test_start, fold.test_end):
        history = causal_window(data, decision_index, lookback)
        target = float(strategy.decide(history))
        if not isfinite(target):
            raise ValueError("strategy returned a non-finite position")
        target = min(max(target, minimum_position), maximum_position)
        turnover = abs(target - current)
        transaction_cost = turnover * cost_rate
        execution_open = float(data.open[decision_index + 1])
        next_open = float(data.open[decision_index + 2])
        gross_return = target * (next_open / execution_open - 1.0)
        net_return = gross_return - transaction_cost
        decisions.append(target)
        net_returns.append(net_return)
        turnover_total += turnover
        cost_total += transaction_cost
        current = target

    # Liquidate at the final known execution boundary and charge the side.
    if net_returns and abs(current) > 0:
        liquidation_cost = abs(current) * cost_rate
        net_returns[-1] -= liquidation_cost
        turnover_total += abs(current)
        cost_total += liquidation_cost
    returns = np.asarray(net_returns, dtype=float)
    equity = np.cumprod(1.0 + returns)
    standard_deviation = float(np.std(returns, ddof=1)) if len(returns) > 1 else 0.0
    sharpe = (
        float(np.mean(returns) / standard_deviation * sqrt(infer_bars_per_year(data)))
        if standard_deviation > 0 else 0.0
    )
    metrics = BacktestMetrics(
        total_return=float(equity[-1] - 1.0) if len(equity) else 0.0,
        maximum_drawdown=_maximum_drawdown(equity),
        annualized_sharpe=sharpe,
        trade_sides=int(np.sum(np.abs(np.diff(np.r_[0.0, decisions, 0.0])) > 1e-12)),
        turnover=float(turnover_total), cost_paid_fraction=float(cost_total),
        invested_fraction=float(np.mean(np.abs(decisions))) if decisions else 0.0,
        evaluated_returns=len(returns),
    )
    return FoldResult(fold, metrics, tuple(decisions), tuple(net_returns))


def validation_folds(
    development_end: int, *, train_bars: int, test_bars: int,
    purge_bars: int, expanding: bool = True,
) -> tuple[Fold, ...]:
    if min(development_end, train_bars, test_bars) <= 0 or purge_bars < 0:
        raise ValueError("invalid fold sizes")
    folds = []
    train_end = train_bars
    while train_end + purge_bars + test_bars <= development_end - 2:
        test_start = train_end + purge_bars
        test_end = test_start + test_bars
        train_start = 0 if expanding else max(0, train_end - train_bars)
        folds.append(Fold(train_start, train_end, test_start, test_end))
        train_end += test_bars
    if not folds:
        raise ValueError("not enough development data for one validation fold")
    return tuple(folds)


def aggregate_fold_metrics(results: Sequence[FoldResult]) -> dict:
    if not results:
        raise ValueError("no fold results")
    return {
        "folds": len(results),
        "mean_return": float(np.mean([row.metrics.total_return for row in results])),
        "median_return": float(np.median([row.metrics.total_return for row in results])),
        "worst_return": float(np.min([row.metrics.total_return for row in results])),
        "mean_maximum_drawdown": float(np.mean([row.metrics.maximum_drawdown for row in results])),
        "worst_maximum_drawdown": float(np.max([row.metrics.maximum_drawdown for row in results])),
        "mean_sharpe": float(np.mean([row.metrics.annualized_sharpe for row in results])),
        "total_trade_sides": int(sum(row.metrics.trade_sides for row in results)),
    }


def run_sealed_experiment(
    data: CandleData, *, strategy_factory: StrategyFactory,
    parameter_candidates: Sequence[Mapping[str, float | int]],
    final_test_bars: int, train_bars: int, validation_bars: int,
    purge_bars: int = 2, lookback: int = 256,
    fee_per_side: float = 0.0010, slippage_per_side: float = 0.0002,
    drawdown_penalty: float = 0.5,
) -> dict:
    """Select on chronological validation, then open the final test exactly once."""
    if not parameter_candidates:
        raise ValueError("parameter_candidates cannot be empty")
    final_test_start = len(data) - int(final_test_bars) - 2
    if final_test_start <= train_bars + purge_bars + validation_bars:
        raise ValueError("not enough data for development plus sealed test")
    folds = validation_folds(
        final_test_start, train_bars=train_bars, test_bars=validation_bars,
        purge_bars=purge_bars,
    )
    selection_rows = []
    for candidate_index, parameters in enumerate(parameter_candidates):
        results = [
            evaluate_fold(
                data, fold, strategy_factory, parameters, lookback=lookback,
                fee_per_side=fee_per_side, slippage_per_side=slippage_per_side,
            )
            for fold in folds
        ]
        summary = aggregate_fold_metrics(results)
        selection_score = summary["mean_return"] - drawdown_penalty * summary["mean_maximum_drawdown"]
        selection_rows.append({
            "candidate_index": candidate_index, "parameters": dict(parameters),
            "selection_score": float(selection_score), "validation": summary,
        })
    selected = max(selection_rows, key=lambda row: (row["selection_score"], -row["candidate_index"]))
    frozen_parameters = dict(selected["parameters"])

    final_fold = Fold(0, final_test_start - purge_bars, final_test_start, len(data) - 2)
    final_result = evaluate_fold(
        data, final_fold, strategy_factory, frozen_parameters, lookback=lookback,
        fee_per_side=fee_per_side, slippage_per_side=slippage_per_side,
    )
    return {
        "contract": {
            "network_access": "none",
            "data_source": data.source_path,
            "data_sha256": data.source_sha256,
            "decision_timing": "history through close[t]; execute at open[t+1]; earn open[t+1] to open[t+2]",
            "selection_data_end_exclusive": final_test_start,
            "purge_bars": purge_bars,
            "final_test_opened_after_parameter_freeze": True,
            "test_reuse_for_retuning": "forbidden; a new idea requires a new still-sealed dataset",
        },
        "configuration": {
            "final_test_bars": final_test_bars, "train_bars": train_bars,
            "validation_bars": validation_bars, "lookback": lookback,
            "fee_per_side": fee_per_side, "slippage_per_side": slippage_per_side,
            "drawdown_penalty": drawdown_penalty,
        },
        "selection_rows": selection_rows,
        "selected_parameters": frozen_parameters,
        "final_test": {
            "fold": asdict(final_result.fold),
            "metrics": asdict(final_result.metrics),
        },
    }


class EMACrossStrategy:
    """Minimal example strategy; replace this class, not the backtest protocol."""
    def __init__(self, short: int, long: int):
        if not 2 <= short < long:
            raise ValueError("EMA windows require 2 <= short < long")
        self.short = int(short)
        self.long = int(long)

    def fit(self, training_data: CandleData) -> None:
        # No fitted parameters. Training data is provided to demonstrate the API.
        if len(training_data) < self.long:
            raise ValueError("training data shorter than long EMA")

    @staticmethod
    def _ema(values: np.ndarray, span: int) -> float:
        alpha = 2.0 / (span + 1.0)
        state = float(values[0])
        for value in values[1:]:
            state = alpha * float(value) + (1.0 - alpha) * state
        return state

    def decide(self, history: CausalWindow) -> float:
        if len(history) < self.long:
            return 0.0
        short_value = self._ema(history.close[-self.short:], self.short)
        long_value = self._ema(history.close[-self.long:], self.long)
        return 1.0 if short_value > long_value else 0.0


def ema_strategy_factory(parameters: Mapping[str, float | int]) -> EMACrossStrategy:
    return EMACrossStrategy(int(parameters["short"]), int(parameters["long"]))


def main() -> None:
    parser = argparse.ArgumentParser(description="Offline leak-resistant crypto backtest")
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--output", type=Path, default=Path("SEALED_BACKTEST_RESULT.json"))
    parser.add_argument("--final-test-bars", type=int, default=800)
    parser.add_argument("--train-bars", type=int, default=1500)
    parser.add_argument("--validation-bars", type=int, default=384)
    parser.add_argument("--purge-bars", type=int, default=2)
    parser.add_argument("--lookback", type=int, default=256)
    args = parser.parse_args()

    data = load_candles_csv(args.csv_path)
    candidates = (
        {"short": 8, "long": 32},
        {"short": 12, "long": 48},
        {"short": 18, "long": 72},
    )
    result = run_sealed_experiment(
        data, strategy_factory=ema_strategy_factory,
        parameter_candidates=candidates, final_test_bars=args.final_test_bars,
        train_bars=args.train_bars, validation_bars=args.validation_bars,
        purge_bars=args.purge_bars, lookback=args.lookback,
    )
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({
        "data_sha256": result["contract"]["data_sha256"],
        "selected_parameters": result["selected_parameters"],
        "final_test": result["final_test"],
        "output": str(args.output.resolve()),
    }, indent=2))


if __name__ == "__main__":
    main()

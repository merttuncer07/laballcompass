# Agent start here

Goal: evaluate or refine crypto-product adapters without changing the experimental ruler.

Read `BACKTEST_PROTOCOL.md`, run all tests, then run `run_product_suite.py` on the fixed user-supplied CSV.
You may edit/add product adapters and predeclare parameter grids. You may not modify execution timing,
splits, costs, input data, or the already-opened sealed result to make a product look better.

Return the complete JSON, the data hash, all candidates, failures, turnover/costs, the frozen selection
rule, and whether the sealed test had previously been inspected. Never describe a backtest as guaranteed
future profit.

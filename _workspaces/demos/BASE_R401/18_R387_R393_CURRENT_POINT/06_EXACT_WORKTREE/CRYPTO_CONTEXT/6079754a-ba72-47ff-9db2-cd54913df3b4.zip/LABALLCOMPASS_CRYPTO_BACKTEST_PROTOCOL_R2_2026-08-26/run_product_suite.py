"""Predeclared multi-product development selection and one-shot sealed test."""
from __future__ import annotations
import argparse,json
from dataclasses import asdict
from pathlib import Path
import numpy as np
from crypto_backtester import Fold,aggregate_fold_metrics,evaluate_fold,load_candles_csv,validation_folds
from crypto_products import PARAMETER_GRIDS,PRODUCTS,product_factory

def _score(summary:dict,penalty:float)->float:
    return float(summary["mean_return"]-penalty*summary["mean_maximum_drawdown"])

def paired_block_bootstrap(a,b,*,block:int=24,repetitions:int=2000,seed:int=20260826)->dict:
    a=np.asarray(a,float); b=np.asarray(b,float)
    if len(a)!=len(b) or not len(a): raise ValueError("paired equal nonempty returns required")
    d=a-b; rng=np.random.default_rng(seed); n=len(d); means=[]
    for _ in range(repetitions):
        pieces=[]
        while sum(len(x) for x in pieces)<n:
            start=int(rng.integers(0,n)); pieces.append(np.take(d,np.arange(start,start+block)%n))
        means.append(float(np.mean(np.concatenate(pieces)[:n])))
    lo,hi=np.quantile(means,[0.025,0.975])
    return {"mean_net_return_difference_per_bar":float(np.mean(d)),"block_bars":block,
            "bootstrap_repetitions":repetitions,"confidence_interval_95":[float(lo),float(hi)],
            "two_sided_zero_p_proxy":float(2*min(np.mean(np.asarray(means)<=0),np.mean(np.asarray(means)>=0)))}

def run_suite(data,*,final_test_bars:int=800,train_bars:int=1500,validation_bars:int=384,purge_bars:int=2,lookback:int=256,fee_per_side:float=.001,slippage_per_side:float=.0002,drawdown_penalty:float=.5)->dict:
    final_start=len(data)-final_test_bars-2
    folds=validation_folds(final_start,train_bars=train_bars,test_bars=validation_bars,purge_bars=purge_bars)
    product_rows=[]
    for product_id in PRODUCTS:
        candidates=[]
        for index,params in enumerate(PARAMETER_GRIDS[product_id]):
            results=[evaluate_fold(data,f,product_factory(product_id),params,lookback=lookback,fee_per_side=fee_per_side,slippage_per_side=slippage_per_side,minimum_position=0,maximum_position=1) for f in folds]
            summary=aggregate_fold_metrics(results); candidates.append({"candidate_index":index,"parameters":dict(params),"selection_score":_score(summary,drawdown_penalty),"validation":summary})
        chosen=max(candidates,key=lambda x:(x["selection_score"],-x["candidate_index"]))
        product_rows.append({"product_id":product_id,"all_candidates":candidates,"selected_on_development":chosen})
    winner=max(product_rows,key=lambda x:(x["selected_on_development"]["selection_score"],x["product_id"]))
    baseline=next(x for x in product_rows if x["product_id"]=="baseline")
    final_fold=Fold(0,final_start-purge_bars,final_start,len(data)-2)
    def final(row):
        p=row["selected_on_development"]["parameters"]
        return evaluate_fold(data,final_fold,product_factory(row["product_id"]),p,lookback=lookback,fee_per_side=fee_per_side,slippage_per_side=slippage_per_side,minimum_position=0,maximum_position=1)
    base_result=final(baseline); winner_result=base_result if winner["product_id"]=="baseline" else final(winner)
    comparison=paired_block_bootstrap(winner_result.net_returns,base_result.net_returns)
    return {"protocol":"LABALLCOMPASS_CRYPTO_BACKTEST_R2","data":{"path":data.source_path,"sha256":data.source_sha256,"bars":len(data)},
        "timing":"observe through close[t], execute open[t+1], earn open[t+1]→open[t+2]","costs":{"fee_per_side":fee_per_side,"slippage_per_side":slippage_per_side,"final_liquidation":True},
        "selection":{"final_test_start":final_start,"purge_bars":purge_bars,"development_product_rows":product_rows,"frozen_winner":winner["product_id"],"rule":"mean fold return minus drawdown penalty; all products and grids predeclared"},
        "sealed_test":{"opened_once":True,"baseline":{"product_id":"baseline","metrics":asdict(base_result.metrics)},"winner":{"product_id":winner["product_id"],"metrics":asdict(winner_result.metrics)},"paired_winner_minus_baseline":comparison},
        "interpretation":{"profit_claim":False,"retuning_after_sealed_test":"FORBIDDEN; label dataset development or use a genuinely untouched dataset","failed_product":"shell-local result, not global product death"}}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("csv",type=Path); ap.add_argument("--output",type=Path,default=Path("CRYPTO_PRODUCT_SUITE_RESULT.json")); ap.add_argument("--final-test-bars",type=int,default=800); ap.add_argument("--train-bars",type=int,default=1500); ap.add_argument("--validation-bars",type=int,default=384); a=ap.parse_args()
    result=run_suite(load_candles_csv(a.csv),final_test_bars=a.final_test_bars,train_bars=a.train_bars,validation_bars=a.validation_bars)
    a.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8"); print(json.dumps({"frozen_winner":result["selection"]["frozen_winner"],"sealed_test":result["sealed_test"],"output":str(a.output.resolve())},indent=2))
if __name__=="__main__":main()

# LabAllCompass Crypto Backtest Protocol R2

Self-contained, offline, leak-resistant comparison kit for five crypto strategy/product shells.

Read `AGENT_START_HERE.md`, then `BACKTEST_PROTOCOL.md`. Run:

```powershell
python -m unittest discover -s tests -v
python run_product_suite.py YOUR_FIXED_OHLCV.csv --output RESULT.json
```

Files:

- `crypto_backtester.py` — immutable experimental ruler: data validation, causal windows, chronological
  folds, costs, liquidation and sealed test.
- `crypto_products.py` — baseline plus SAMG, predictable-variance, guarantee-transport and synthesis
  adapters.
- `run_product_suite.py` — development comparison, parameter freeze, final baseline/winner comparison and
  paired block bootstrap.
- `tests/test_protocol.py` — causality, future-mutation invariance, product execution and local-authority
  tests.

No market data is included. This prevents an agent from silently treating a bundled sample as external
validation. The user supplies the fixed CSV and its hash is recorded automatically.

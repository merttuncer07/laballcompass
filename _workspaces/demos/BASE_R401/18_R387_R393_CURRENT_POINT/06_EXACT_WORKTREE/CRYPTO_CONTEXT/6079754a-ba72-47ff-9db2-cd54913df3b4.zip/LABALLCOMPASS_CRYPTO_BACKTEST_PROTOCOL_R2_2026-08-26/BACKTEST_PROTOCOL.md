# LabAllCompass Crypto Product Backtest Protocol R2

## Purpose

This package lets an agent test the same baseline, individual Lab-product gates, and a synthesis under one
unchanged causal execution engine. It is a refinement instrument, not evidence of guaranteed profit.

## Non-negotiable experiment contract

1. Use a fixed local OHLCV CSV. Do not download or append data during an experiment.
2. Record its SHA-256. A changed hash is a different experiment.
3. Observe only through close `t`; execute at open `t+1`; earn open `t+1` to open `t+2`.
4. Include fee, slippage, turnover, and final liquidation.
5. Fit on training data and select only on chronological validation folds separated by a purge gap.
6. Product list, parameter grids, selection score, costs, and final-test boundary must be declared before
   opening the sealed test.
7. Open the sealed test once for the frozen development winner and the predeclared baseline comparator.
8. Never tune after reading sealed results. The file then becomes development data; use a genuinely unseen
   market/period for another confirmation.
9. Report every product and every parameter candidate—not only the winner.
10. Treat a failure as shell-local. It diagnoses this adapter/market/period; it does not kill the underlying
    mechanism.

## Included product adapters

- `baseline`: adaptive-memory long-only momentum (LMDE-like comparison baseline).
- `samg`: selection-aware memory gate; blocks only an uncertified fresh entry.
- `pvag`: predictable-variance alarm; blocks only fresh entry under variance excursion.
- `gtg`: guarantee-transport gate; blocks only fresh entry outside training mean/volatility support.
- `synthesis`: SAMG + PVAG + GTG under the same local-authority shell.

All gates preserve an already-held long. This tests the project’s observed distinction between harmful
fresh authority and potentially profitable stale persistence.

## Required CSV

Columns:

`open_time_ms,close_time_ms,open,high,low,close,volume`

Rows must be strictly chronological with positive, geometrically valid OHLC values.

## Commands

```powershell
python -m unittest discover -s tests -v
python run_product_suite.py BTCUSDT_1h.csv --output BTC_PRODUCT_SUITE.json
```

For quick model refinement, change only `crypto_products.py` or add a new product factory and a small
predeclared grid. Do not fork or rewrite `crypto_backtester.py` timing/split/cost logic for each idea.

## Reading the result

The development table answers which shell deserves the one sealed evaluation. The sealed section reports
the baseline, frozen winner, and paired block-bootstrap interval for per-bar net-return difference. A
positive historical return without a stable paired advantage, realistic turnover, and controlled drawdown
is not sufficient evidence of improvement.

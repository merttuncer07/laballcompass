"""Predeclared causal Lab-product adapters for comparable crypto backtests.

These are research prototypes, not claims of alpha.  Every gate has authority
only over a fresh long entry; it cannot liquidate an already-held long.
"""
from __future__ import annotations
from math import sqrt
from typing import Mapping
import numpy as np
from crypto_backtester import CandleData, CausalWindow

def _returns(values:np.ndarray)->np.ndarray:
    return np.diff(np.log(np.asarray(values,dtype=float)))

class AdaptiveMemoryMomentum:
    product_id="P0_LMDE_LIKE_BASELINE"
    def __init__(self,p:Mapping[str,float|int]):
        self.max_lag=int(p.get("max_lag",12)); self.threshold=float(p.get("threshold",0.0)); self.selected_lag=1
    def fit(self,data:CandleData)->None:
        if len(data)<max(80,self.max_lag+3): raise ValueError("training data too short")
        close=np.log(data.close); future=np.diff(np.log(data.open))
        scores=[]
        for lag in range(1,self.max_lag+1):
            t=np.arange(lag,len(data)-2)
            signal=np.sign(close[t]-close[t-lag]); target=future[t+1]
            scores.append(float(np.mean(signal*target)))
        self.lag_scores=np.asarray(scores); self.selected_lag=int(np.argmax(self.lag_scores))+1
    def raw_long(self,h:CausalWindow)->bool:
        lag=self.selected_lag
        return len(h)>lag and float(np.log(h.close[-1]/h.close[-1-lag]))>self.threshold
    def decide(self,h:CausalWindow)->float: return 1.0 if self.raw_long(h) else 0.0

class FreshEntryGateBase(AdaptiveMemoryMomentum):
    """Local authority shell: preserve a held long even if a gate closes."""
    product_id="ABSTRACT_FRESH_ENTRY_GATE"
    def __init__(self,p): super().__init__(p); self._held=False
    def gate_open(self,h:CausalWindow)->bool: return True
    def decide(self,h:CausalWindow)->float:
        raw=self.raw_long(h)
        if not raw: self._held=False; return 0.0
        if self._held: return 1.0
        if self.gate_open(h): self._held=True; return 1.0
        return 0.0

class SelectionAwareMemoryGate(FreshEntryGateBase):
    product_id="P1_SAMG_SELECTION_AWARE_MEMORY_GATE"
    def fit(self,data:CandleData)->None:
        super().fit(data); close=np.log(data.close); future=np.diff(np.log(data.open)); lag=self.selected_lag
        t=np.arange(max(1,lag),len(data)-2)
        target=future[t+1]
        chosen=np.sign(close[t]-close[t-lag]); reference=np.sign(close[t]-close[t-1])
        gain=(chosen-reference)*target; se=float(np.std(gain,ddof=1)/sqrt(len(gain))) if len(gain)>1 else float("inf")
        z=float(getattr(self,"selection_z",1.96)); self.selection_certified=(lag==1 or float(np.mean(gain))>z*se)
    def __init__(self,p):
        super().__init__(p); self.selection_z=float(p.get("selection_z",1.96))
    def gate_open(self,h:CausalWindow)->bool: return self.selection_certified

class PredictableVarianceGate(FreshEntryGateBase):
    product_id="P2_PVAG_PREDICTABLE_VARIANCE_ALARM_GATE"
    def __init__(self,p):
        super().__init__(p); self.variance_window=int(p.get("variance_window",32)); self.variance_multiple=float(p.get("variance_multiple",2.0))
    def fit(self,data:CandleData)->None:
        super().fit(data); r=_returns(data.close); self.train_variance=max(float(np.var(r,ddof=1)),1e-15)
    def gate_open(self,h:CausalWindow)->bool:
        if len(h)<self.variance_window+1:return False
        recent=_returns(h.close[-self.variance_window-1:]); return float(np.mean(recent**2))<=self.variance_multiple*self.train_variance

class GuaranteeTransportGate(FreshEntryGateBase):
    product_id="P3_GTG_GUARANTEE_TRANSPORT_GATE"
    def __init__(self,p):
        super().__init__(p); self.transport_window=int(p.get("transport_window",48)); self.mean_z=float(p.get("mean_z",2.5)); self.vol_ratio=float(p.get("vol_ratio",2.5))
    def fit(self,data:CandleData)->None:
        super().fit(data); r=_returns(data.close); self.train_mean=float(np.mean(r)); self.train_std=max(float(np.std(r,ddof=1)),1e-12)
    def gate_open(self,h:CausalWindow)->bool:
        if len(h)<self.transport_window+1:return False
        r=_returns(h.close[-self.transport_window-1:]); mean_se=self.train_std/sqrt(len(r))
        return abs(float(np.mean(r))-self.train_mean)<=self.mean_z*mean_se and float(np.std(r,ddof=1))<=self.vol_ratio*self.train_std

class LocalAuthoritySynthesis(FreshEntryGateBase):
    product_id="P4_LAR_SAMG_PVAG_GTG_SYNTHESIS"
    def __init__(self,p):
        super().__init__(p); self.selection_z=float(p.get("selection_z",1.64)); self.variance_window=int(p.get("variance_window",32)); self.variance_multiple=float(p.get("variance_multiple",2.5)); self.transport_window=int(p.get("transport_window",48)); self.mean_z=float(p.get("mean_z",3.0)); self.vol_ratio=float(p.get("vol_ratio",3.0))
    def fit(self,data:CandleData)->None:
        super().fit(data); r=_returns(data.close); self.train_mean=float(np.mean(r)); self.train_std=max(float(np.std(r,ddof=1)),1e-12); self.train_variance=max(float(np.var(r,ddof=1)),1e-15)
        close=np.log(data.close); future=np.diff(np.log(data.open)); lag=self.selected_lag; t=np.arange(max(1,lag),len(data)-2); target=future[t+1]
        gain=(np.sign(close[t]-close[t-lag])-np.sign(close[t]-close[t-1]))*target
        se=float(np.std(gain,ddof=1)/sqrt(len(gain))) if len(gain)>1 else float("inf"); self.selection_certified=(lag==1 or float(np.mean(gain))>self.selection_z*se)
    def gate_open(self,h:CausalWindow)->bool:
        if not self.selection_certified or len(h)<max(self.variance_window,self.transport_window)+1:return False
        rv=_returns(h.close[-self.variance_window-1:]); rt=_returns(h.close[-self.transport_window-1:]); mean_se=self.train_std/sqrt(len(rt))
        return (float(np.mean(rv**2))<=self.variance_multiple*self.train_variance and abs(float(np.mean(rt))-self.train_mean)<=self.mean_z*mean_se and float(np.std(rt,ddof=1))<=self.vol_ratio*self.train_std)

PRODUCTS={
    "baseline":AdaptiveMemoryMomentum,
    "samg":SelectionAwareMemoryGate,
    "pvag":PredictableVarianceGate,
    "gtg":GuaranteeTransportGate,
    "synthesis":LocalAuthoritySynthesis,
}
def product_factory(product_id:str):
    cls=PRODUCTS[product_id]
    return lambda parameters: cls(parameters)

PARAMETER_GRIDS={
    "baseline":({"max_lag":6},{"max_lag":12}),
    "samg":({"max_lag":6,"selection_z":1.64},{"max_lag":12,"selection_z":1.96}),
    "pvag":({"max_lag":6,"variance_window":24,"variance_multiple":2.0},{"max_lag":12,"variance_window":48,"variance_multiple":3.0}),
    "gtg":({"max_lag":6,"transport_window":32,"mean_z":2.5,"vol_ratio":2.5},{"max_lag":12,"transport_window":64,"mean_z":3.0,"vol_ratio":3.0}),
    "synthesis":({"max_lag":6,"selection_z":1.64,"variance_window":24,"variance_multiple":2.5,"transport_window":48,"mean_z":3.0,"vol_ratio":3.0},{"max_lag":12,"selection_z":1.96,"variance_window":48,"variance_multiple":3.0,"transport_window":64,"mean_z":3.5,"vol_ratio":3.5}),
}

import unittest
import numpy as np
from crypto_backtester import CandleData,Fold,causal_window,evaluate_fold
from crypto_products import PRODUCTS,PARAMETER_GRIDS,product_factory
from run_product_suite import paired_block_bootstrap,run_suite

def data(n=1800,mutate_after=None):
    i=np.arange(n,dtype=float); opening=100*np.exp(.00015*i+.008*np.sin(i/13))
    if mutate_after is not None: opening[mutate_after:]*=np.exp(.1*np.sin(i[mutate_after:]/2))
    close=opening*(1+.001*np.sin(i/7)); values={"open_time_ms":np.asarray(i*3_600_000,np.int64),"close_time_ms":np.asarray(i*3_600_000+3_599_999,np.int64),"open":opening,"high":np.maximum(opening,close)*1.001,"low":np.minimum(opening,close)*.999,"close":close,"volume":np.full(n,10.)}
    for v in values.values():v.flags.writeable=False
    return CandleData(**values,source_path="synthetic",source_sha256="fixed")

class ProtocolTests(unittest.TestCase):
    def test_window_is_prefix_only_read_only(self):
        w=causal_window(data(),500,64); self.assertEqual(w.end_index,500); self.assertEqual(w.close[-1],data().close[500])
        with self.assertRaises(ValueError):w.close[-1]=0
    def test_future_mutation_does_not_change_past(self):
        f=Fold(0,500,550,800); kw=dict(strategy_factory=product_factory("baseline"),parameters=PARAMETER_GRIDS["baseline"][0],lookback=128,minimum_position=0,maximum_position=1)
        a=evaluate_fold(data(),f,**kw); b=evaluate_fold(data(mutate_after=900),f,**kw); self.assertEqual(a.net_returns,b.net_returns)
    def test_all_products_execute_with_costs(self):
        f=Fold(0,500,550,700)
        for product_id in PRODUCTS:
            r=evaluate_fold(data(),f,product_factory(product_id),PARAMETER_GRIDS[product_id][0],lookback=128,minimum_position=0,maximum_position=1)
            self.assertEqual(r.metrics.evaluated_returns,150); self.assertGreaterEqual(r.metrics.cost_paid_fraction,0)
    def test_local_gates_preserve_existing_long(self):
        # Gate subclasses must never liquidate solely because a validity gate closes.
        from crypto_products import FreshEntryGateBase
        class Closed(FreshEntryGateBase):
            def gate_open(self,h):return False
        s=Closed({"max_lag":2}); s.fit(data(600)); s._held=True; s.raw_long=lambda h:True
        self.assertEqual(s.decide(causal_window(data(600),500,64)),1.0)
    def test_bootstrap_is_deterministic(self):
        a=np.linspace(-.01,.02,100); b=np.zeros(100); self.assertEqual(paired_block_bootstrap(a,b),paired_block_bootstrap(a,b))
    def test_suite_freezes_before_final_and_reports_all(self):
        r=run_suite(data(2600),final_test_bars=300,train_bars=600,validation_bars=250,lookback=128)
        self.assertEqual(len(r["selection"]["development_product_rows"]),len(PRODUCTS)); self.assertTrue(r["sealed_test"]["opened_once"]); self.assertIn(r["selection"]["frozen_winner"],PRODUCTS)

if __name__=="__main__":unittest.main()
